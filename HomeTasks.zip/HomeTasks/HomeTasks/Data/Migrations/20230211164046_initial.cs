﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HomeTasks.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HomeTask",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<int>(type: "int", nullable: false),
                    IsDone = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HomeTask", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ChildTask",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HomeTasksId = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChildTask", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ChildTask_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ChildTask_HomeTask_HomeTasksId",
                        column: x => x.HomeTasksId,
                        principalTable: "HomeTask",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_ChildTask_HomeTasksId",
                table: "ChildTask",
                column: "HomeTasksId");

            migrationBuilder.CreateIndex(
                name: "IX_ChildTask_UserId",
                table: "ChildTask",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ChildTask");

            migrationBuilder.DropTable(
                name: "HomeTask");
        }
    }
}
