﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using HomeTasks.Models;

namespace HomeTasks.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<HomeTasks.Models.HomeTask> HomeTask { get; set; }
        public DbSet<HomeTasks.Models.ChildTask> ChildTask { get; set; }
    }
}