﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeTasks.Data;
using HomeTasks.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;

namespace HomeTasks.Controllers
{
    [Authorize]
    public class ChildTasksController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public ChildTasksController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: ChildTasks
        public async Task<IActionResult> Index()
        {

            var applicationDbContext = _context.ChildTask.Include(c => c.HomeTasks).Where(c => c.UserId == _userManager.GetUserId(User));
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ChildTasks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.ChildTask == null)
            {
                return NotFound();
            }

            var childTask = await _context.ChildTask
                .Include(c => c.HomeTasks)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (childTask == null)
            {
                return NotFound();
            }

            return View(childTask);
        }

        // GET: ChildTasks/Create
        public IActionResult Create()
        {
            var homeTasks = _context.HomeTask.Where(h => h.IsDone == false);

            ViewData["HomeTasksId"] = new SelectList(homeTasks, "Id", "Name");
            ViewData["AreVacancies"] = homeTasks.Any();
            return View();
        }

        // POST: ChildTasks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,HomeTasksId")] ChildTask childTask)
        {

            childTask.UserId = _userManager.GetUserId(User);
            _context.HomeTask.Where(h => h.Id == childTask.HomeTasksId).First().IsDone = true;
            _context.Add(childTask);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));

            ViewData["HomeTasksId"] = new SelectList(_context.HomeTask, "Id", "Id", childTask.HomeTasksId);
            return View(childTask);
        }

        // GET: ChildTasks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.ChildTask == null)
            {
                return NotFound();
            }

            var childTask = await _context.ChildTask
                .Include(c => c.HomeTasks)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (childTask == null)
            {
                return NotFound();
            }

            return View(childTask);
        }

        // POST: ChildTasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.ChildTask == null)
            {
                return Problem("Entity set 'ApplicationDbContext.ChildTask'  is null.");
            }
            var childTask = await _context.ChildTask.FindAsync(id);
            if (childTask != null)
            {
                _context.HomeTask.Where(h => h.Id == childTask.HomeTasksId).First().IsDone = false;
                _context.ChildTask.Remove(childTask);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ChildTaskExists(int id)
        {
          return _context.ChildTask.Any(e => e.Id == id);
        }
    }
}
