﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HomeTasks.Data;
using HomeTasks.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

namespace HomeTasks.Controllers
{

    public class HomeTasksController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager;

        public HomeTasksController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: HomeTasks
        [Authorize]
        public async Task<IActionResult> Index()
        {
            var user = await _context.Users.FindAsync(_userManager.GetUserId(User));

            var roles = await _userManager.GetRolesAsync(user);     
            if (roles.Any(role => role == "Administrator"))       
            {
                return View(await _context.HomeTask.ToListAsync());
            }

            return View(await _context.HomeTask.Where(t => t.IsDone == false).ToListAsync());
        }

        [Authorize(Roles = "Administrator")]
        // GET: HomeTasks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.HomeTask == null)
            {
                return NotFound();
            }

            var applicationDbContext = _context.ChildTask.Include(u => u.HomeTasks).Include(u => u.User).Where(m => m.HomeTasksId == id);

            var homeTask = await _context.HomeTask
                .FirstOrDefaultAsync(m => m.Id == id);

            ViewData["homeTask"]= homeTask;

            return View(await applicationDbContext.ToListAsync());
        }

        // GET: HomeTasks/Create
        [Authorize(Roles = "Administrator")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: HomeTasks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Create([Bind("Id,Name,Price")] HomeTask homeTask)
        {
            if (ModelState.IsValid)
            {
                _context.Add(homeTask);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(homeTask);
        }

        // GET: HomeTasks/Edit/5
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.HomeTask == null)
            {
                return NotFound();
            }

            var homeTask = await _context.HomeTask.FindAsync(id);
            if (homeTask == null)
            {
                return NotFound();
            }
            return View(homeTask);
        }

        // POST: HomeTasks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Price, IsDone")] HomeTask homeTask)
        {
            if (id != homeTask.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(homeTask);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!HomeTaskExists(homeTask.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(homeTask);
        }

        // GET: HomeTasks/Delete/5
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.HomeTask == null)
            {
                return NotFound();
            }

            var homeTask = await _context.HomeTask
                .FirstOrDefaultAsync(m => m.Id == id);
            if (homeTask == null)
            {
                return NotFound();
            }

            return View(homeTask);
        }

        // POST: HomeTasks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Administrator")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.HomeTask == null)
            {
                return Problem("Entity set 'ApplicationDbContext.HomeTask'  is null.");
            }
            var homeTask = await _context.HomeTask.FindAsync(id);
            if (homeTask != null)
            {
                var childTasks = await _context.ChildTask.Where(m => m.HomeTasksId == id).ToListAsync();
                foreach (ChildTask childTask in childTasks)
                {
                    _context.ChildTask.Remove(childTask);
                }
                _context.HomeTask.Remove(homeTask);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool HomeTaskExists(int id)
        {
          return _context.HomeTask.Any(e => e.Id == id);
        }
    }
}
