﻿using Microsoft.AspNetCore.Identity;

namespace HomeTasks.Models
{
    public class ChildTask
    {
        public int Id { get; set; }
        public int? HomeTasksId { get; set; }
        public virtual HomeTask? HomeTasks { get; set; }
        public string UserId { get; set; }
        public virtual IdentityUser? User { get; set; }

    }
}
